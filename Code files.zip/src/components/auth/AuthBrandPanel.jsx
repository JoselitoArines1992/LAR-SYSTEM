import { ShieldCheck } from "lucide-react";

const STEPS = [
  "Account Officer files the request",
  "Unit Manager recommends with remarks",
  "Area Manager grants final approval",
];

// The navy story panel beside the auth forms — branding plus the routing chain.
export default function AuthBrandPanel() {
  return (
    <div className="lar-navy-gradient relative hidden overflow-hidden lg:flex lg:flex-col lg:justify-between lg:p-12">
      <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-white/10 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-28 -left-20 h-72 w-72 rounded-full bg-sky-400/20 blur-3xl" />

      <div className="relative flex items-center gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-xl bg-white/15 font-heading text-[17px] font-extrabold text-white ring-1 ring-white/25">
          L
        </span>
        <span className="leading-none">
          <span className="block font-heading text-[16px] font-extrabold tracking-tight text-white">LAR-Sys</span>
          <span className="mt-1.5 block text-[10px] font-semibold uppercase tracking-[0.18em] text-white/60">
            CARD MRI Rizal Bank
          </span>
        </span>
      </div>

      <div className="relative">
        <h2 className="max-w-sm font-heading text-[1.9rem] font-extrabold leading-[1.15] text-white">
          Leave routing that never skips a Unit Manager.
        </h2>
        <ol className="mt-8 space-y-4">
          {STEPS.map((step, index) => (
            <li key={step} className="flex items-start gap-3">
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-white/15 text-[11.5px] font-bold text-white ring-1 ring-white/20">
                {index + 1}
              </span>
              <span className="pt-1 text-[13px] leading-snug text-white/75">{step}</span>
            </li>
          ))}
        </ol>
      </div>

      <div className="relative flex items-start gap-2.5 rounded-2xl bg-white/10 p-4 ring-1 ring-white/15">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-white/80" />
        <p className="text-[11.5px] leading-relaxed text-white/70">
          Sequential by design — no filing reaches the Area Manager without the Unit Manager&apos;s endorsement.
        </p>
      </div>
    </div>
  );
}