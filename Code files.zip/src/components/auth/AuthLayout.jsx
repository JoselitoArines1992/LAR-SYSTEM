import AuthBrandPanel from "./AuthBrandPanel";

// Full-screen shell shared by the auth pages: branded navy panel on desktop,
// the form on the right. Children stay untouched, so every flow still works.
export function AuthLayout({ icon: Icon, title, subtitle, footer, children }) {
  return (
    <div className="min-h-screen bg-background text-foreground lg:grid lg:grid-cols-[minmax(0,1fr)_minmax(0,1.02fr)]">
      <AuthBrandPanel />

      <div className="flex min-h-screen items-center justify-center px-4 py-10 sm:px-8">
        <div className="w-full max-w-md">
          <div className="mb-6 flex items-center gap-2.5 lg:hidden">
            <span className="lar-navy-gradient grid h-10 w-10 place-items-center rounded-xl font-heading text-[15px] font-extrabold text-white shadow-sm">
              L
            </span>
            <span className="leading-none">
              <span className="block font-heading text-[15px] font-extrabold tracking-tight text-primary">LAR-Sys</span>
              <span className="mt-1 block text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
                CARD MRI Rizal Bank
              </span>
            </span>
          </div>

          <div className="mb-6 flex items-start gap-3">
            {Icon && (
              <span className="mt-0.5 hidden h-11 w-11 shrink-0 place-items-center rounded-xl bg-accent text-primary ring-1 ring-primary/10 sm:grid">
                <Icon className="h-5 w-5" aria-hidden="true" />
              </span>
            )}
            <div>
              <h1 className="font-heading text-[26px] font-extrabold leading-tight tracking-tight text-primary">
                {title}
              </h1>
              {subtitle && <p className="mt-1.5 text-[13.5px] leading-relaxed text-muted-foreground">{subtitle}</p>}
            </div>
          </div>

          <div className="lar-panel p-6 text-card-foreground sm:p-8">{children}</div>

          {footer && <p className="mt-6 text-center text-sm text-muted-foreground">{footer}</p>}
        </div>
      </div>
    </div>
  );
}