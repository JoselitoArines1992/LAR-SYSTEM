import { Link } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";
import { formatDate } from "@/lib/roles";
import StatusBadge from "@/components/StatusBadge";

function initials(name = "") {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();
}

export default function LeaveRow({ leave }) {
  return (
    <Link
      to="/request/$leaveId"
      params={{ leaveId: leave.leave_id }}
      className="group flex items-center gap-3 px-4 py-3.5 transition hover:bg-secondary/50"
    >
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-secondary text-[11px] font-bold text-primary">
        {initials(leave.employee_name)}
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
          <p className="truncate text-[13.5px] font-semibold text-foreground">{leave.employee_name}</p>
          <span className="font-mono text-[10.5px] text-muted-foreground">{leave.leave_id}</span>
        </div>
        <p className="mt-0.5 truncate text-[11.5px] text-muted-foreground">
          {leave.leave_type} · {formatDate(leave.start_date)} – {formatDate(leave.end_date)} · {leave.days_count} day
          {leave.days_count > 1 ? "s" : ""}
        </p>
      </div>
      <StatusBadge status={leave.overall_status} short className="hidden sm:inline-flex" />
      <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground/60 transition group-hover:translate-x-0.5 group-hover:text-primary" />
    </Link>
  );
}