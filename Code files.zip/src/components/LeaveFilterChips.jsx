import { cn } from "@/lib/utils";

// Pill filter row: `filters` is [{ key, label, count? }].
export default function LeaveFilterChips({ filters, value, onChange, className }) {
  return (
    <div className={cn("flex flex-wrap gap-1.5", className)}>
      {filters.map((item) => {
        const selected = value === item.key;
        return (
          <button
            key={item.key}
            type="button"
            onClick={() => onChange(item.key)}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-[12px] font-semibold transition",
              selected
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card text-muted-foreground hover:border-primary/30 hover:text-foreground",
            )}
          >
            {item.label}
            {typeof item.count === "number" && (
              <span
                className={cn(
                  "rounded-full px-1.5 text-[10px] font-bold",
                  selected ? "bg-primary-foreground/20" : "bg-secondary text-foreground/70",
                )}
              >
                {item.count}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}