import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { formatDate } from "@/lib/roles";
import StatusBadge from "@/components/StatusBadge";

export default function ReviewRow({ leave, actionable }) {
  return (
    <div className="flex flex-col gap-3 border-b border-border/70 px-4 py-3.5 transition last:border-b-0 hover:bg-secondary/40 md:grid md:grid-cols-[1.6fr_1.1fr_0.5fr_1fr_auto] md:items-center md:gap-4">
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
          <p className="truncate text-[13.5px] font-semibold text-foreground">{leave.employee_name}</p>
          <span className="font-mono text-[10.5px] text-muted-foreground">{leave.leave_id}</span>
        </div>
        <p className="mt-0.5 truncate text-[11.5px] text-muted-foreground">
          {leave.leave_type} · {leave.unit_branch}
        </p>
      </div>

      <div className="text-[12px] text-foreground/85">
        <span className="block text-[10px] font-semibold uppercase tracking-[0.1em] text-muted-foreground md:hidden">
          Inclusive dates
        </span>
        {formatDate(leave.start_date)} – {formatDate(leave.end_date)}
      </div>

      <div className="text-[12px] font-semibold text-primary">
        <span className="block text-[10px] font-semibold uppercase tracking-[0.1em] text-muted-foreground md:hidden">Days</span>
        {leave.days_count}d
      </div>

      <div className="text-[12px] text-foreground/85">
        <span className="block text-[10px] font-semibold uppercase tracking-[0.1em] text-muted-foreground md:hidden">
          Reliever
        </span>
        {leave.reliever_name ?? "—"}
      </div>

      <div className="flex items-center justify-between gap-3 md:justify-end">
        <StatusBadge status={leave.overall_status} short />
        <Link
          to="/request/$leaveId"
          params={{ leaveId: leave.leave_id }}
          className={
            actionable
              ? "inline-flex h-9 items-center gap-1.5 rounded-lg bg-primary px-3 text-[12px] font-semibold text-white shadow-sm transition hover:bg-primary/90"
              : "inline-flex h-9 items-center gap-1.5 rounded-lg border border-border px-3 text-[12px] font-semibold text-primary transition hover:border-primary/30 hover:bg-secondary"
          }
        >
          {actionable ? "Review" : "Open"}
          <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>
    </div>
  );
}