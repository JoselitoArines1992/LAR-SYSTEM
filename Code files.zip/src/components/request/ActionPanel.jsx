import { useState } from "react";
import { toast } from "sonner";
import { AlertCircle, Loader2, ThumbsDown, ThumbsUp } from "lucide-react";
import { useRole } from "@/lib/RoleContext";
import { recordAmDecision, recordUmDecision } from "@/lib/workflow";
import { roleMeta } from "@/lib/roles";

export default function ActionPanel({ leave, workflow, onDone }) {
  const { active, refresh } = useRole();
  const [remarks, setRemarks] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  if (!active) return null;

  const isUmTurn = leave.overall_status === "Pending UM" && active.role === "UM";
  const isAmTurn = leave.overall_status === "Pending AM" && active.role === "AM";

  const waitingNote = (() => {
    if (leave.overall_status === "Pending UM") {
      if (active.role === "AO") return "Submitted. Waiting for your Unit Manager's Level‑1 recommendation before it reaches the Area Manager.";
      if (active.role === "AM") return "This request is still with the Unit Manager. The Area Manager cannot act until it is endorsed.";
      return "This request belongs to another unit's queue.";
    }
    if (leave.overall_status === "Pending AM") {
      if (active.role === "AO") return "Endorsed by your Unit Manager. Waiting for the Area Manager's final approval.";
      if (active.role === "UM") return "Already endorsed. Waiting for the Area Manager's final approval.";
      return "This request belongs to another cluster.";
    }
    return leave.overall_status === "Approved"
      ? "Workflow complete — leave approved and credits deducted."
      : "Workflow closed — this request was rejected.";
  })();

  if (!isUmTurn && !isAmTurn) {
    return (
      <div className="lar-panel p-4">
        <p className="lar-eyebrow">Workflow status</p>
        <p className="mt-2 text-[12.5px] leading-relaxed text-muted-foreground">{waitingNote}</p>
      </div>
    );
  }

  const act = async (decision) => {
    if (!remarks.trim()) {
      setError("Remarks are required before recording a decision.");
      return;
    }
    setError("");
    setBusy(true);
    try {
      if (isUmTurn) {
        await recordUmDecision({ leave, workflow, um: active, decision, remarks: remarks.trim() });
        toast.success(decision === "Recommended" ? "Endorsed to the Area Manager." : "Request rejected.");
      } else {
        await recordAmDecision({ leave, workflow, am: active, decision, remarks: remarks.trim() });
        toast.success(
          decision === "Approved"
            ? `Leave approved — ${leave.days_count} day(s) deducted from ${leave.employee_name}.`
            : "Request rejected.",
        );
      }
      await refresh();
      setRemarks("");
      await onDone?.();
    } catch (actionError) {
      setError(actionError.message ?? "Unable to record the decision.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="lar-panel p-4">
      <div className="flex items-center justify-between gap-3">
        <p className="lar-eyebrow">{isUmTurn ? "Level‑1 recommendation" : "Level‑2 final approval"}</p>
        <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.1em] text-primary">
          {roleMeta(active.role).code}
        </span>
      </div>
      <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">
        {isUmTurn
          ? "Confirm the assigned reliever covers the field center meetings, then endorse or reject with remarks."
          : `Approving releases the leave and deducts ${leave.days_count ?? 0} day(s) from ${leave.employee_name}'s balance.`}
      </p>

      <label className="lar-field-label mt-3.5" htmlFor="remarks">
        Remarks <span className="text-rose-600">*</span>
      </label>
      <textarea
        id="remarks"
        rows={3}
        value={remarks}
        onChange={(event) => setRemarks(event.target.value)}
        placeholder={isUmTurn ? "e.g. Reliever confirmed for all center meetings on these dates." : "e.g. Approved — cluster coverage validated."}
        className="w-full rounded-xl border border-input bg-card px-3.5 py-2.5 text-[13px] shadow-sm transition placeholder:text-muted-foreground/70 focus:border-primary/40 focus:outline-none focus:ring-4 focus:ring-primary/10"
      />

      {error && (
        <div className="mt-2.5 flex items-start gap-1.5 rounded-lg border border-rose-200 bg-rose-50 px-2.5 py-2">
          <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-rose-600" />
          <p className="text-[11.5px] font-medium text-rose-800">{error}</p>
        </div>
      )}

      <div className="mt-3 grid grid-cols-2 gap-2">
        <button
          type="button"
          disabled={busy}
          onClick={() => act(isUmTurn ? "Recommended" : "Approved")}
          className="inline-flex h-10 items-center justify-center gap-1.5 rounded-xl bg-primary text-[12.5px] font-semibold text-white shadow-sm transition hover:bg-primary/90 disabled:opacity-60"
        >
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ThumbsUp className="h-3.5 w-3.5" />}
          {isUmTurn ? "Recommend" : "Approve"}
        </button>
        <button
          type="button"
          disabled={busy}
          onClick={() => act("Rejected")}
          className="inline-flex h-10 items-center justify-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 text-[12.5px] font-semibold text-rose-700 transition hover:bg-rose-100 disabled:opacity-60"
        >
          <ThumbsDown className="h-3.5 w-3.5" />
          Reject
        </button>
      </div>
    </div>
  );
}