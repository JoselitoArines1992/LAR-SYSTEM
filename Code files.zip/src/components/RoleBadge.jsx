import { roleMeta } from "@/lib/roles";
import { cn } from "@/lib/utils";

export default function RoleBadge({ role, className, showLabel = true, size = "md" }) {
  const meta = roleMeta(role);
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full font-semibold ring-1",
        size === "sm" ? "px-2 py-0.5 text-[10px] tracking-[0.12em]" : "px-2.5 py-1 text-[11px] tracking-[0.1em]",
        meta.badgeClass,
        className,
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", meta.dotClass)} />
      {meta.code.toUpperCase()}
      {showLabel && <span className="font-medium tracking-normal opacity-80">· {meta.label}</span>}
    </span>
  );
}