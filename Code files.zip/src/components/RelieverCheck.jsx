import { CalendarCheck2, TriangleAlert, UserCheck } from "lucide-react";
import { formatDate, overlapping } from "@/lib/roles";
import StatusBadge from "@/components/StatusBadge";

export default function RelieverCheck({ relieverId, relieverName, startDate, endDate, leaves }) {
  if (!relieverId) {
    return (
      <div className="flex items-start gap-2.5 rounded-xl border border-amber-200 bg-amber-50/70 p-3">
        <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
        <p className="text-[12px] leading-relaxed text-amber-900">No reliever assigned yet — assignment is mandatory.</p>
      </div>
    );
  }

  const conflicts = (leaves ?? []).filter(
    (leave) =>
      leave.employee_id === relieverId &&
      leave.overall_status !== "Rejected" &&
      overlapping(startDate, endDate, leave.start_date, leave.end_date),
  );

  if (conflicts.length) {
    return (
      <div className="rounded-xl border border-rose-200 bg-rose-50/70 p-3.5">
        <div className="flex items-start gap-2.5">
          <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0 text-rose-600" />
          <div>
            <p className="text-[12.5px] font-semibold text-rose-900">
              {relieverName} is unavailable on these dates
            </p>
            <p className="mt-0.5 text-[11.5px] text-rose-700">
              {conflicts.length} overlapping filing{conflicts.length > 1 ? "s" : ""} on record.
            </p>
          </div>
        </div>
        <ul className="mt-2.5 space-y-1.5">
          {conflicts.slice(0, 3).map((leave) => (
            <li key={leave.id} className="flex flex-wrap items-center gap-2 text-[11.5px] text-rose-900/80">
              <span className="font-medium">
                {formatDate(leave.start_date)} – {formatDate(leave.end_date)}
              </span>
              <StatusBadge status={leave.overall_status} short className="scale-[0.92]" />
            </li>
          ))}
        </ul>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex items-start gap-2.5 rounded-xl border border-emerald-200 bg-emerald-50/70 p-3.5">
        <UserCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
        <div>
          <p className="text-[12.5px] font-semibold text-emerald-900">{relieverName} is available</p>
          <p className="mt-0.5 text-[11.5px] text-emerald-700">No overlapping leave on record for this period.</p>
        </div>
      </div>
      <div className="flex items-start gap-2 rounded-xl border border-border bg-secondary/40 p-3">
        <CalendarCheck2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
        <p className="text-[11.5px] leading-relaxed text-muted-foreground">
          Field center meeting coverage still needs the Unit Manager's recommendation before the request moves to the Area
          Manager.
        </p>
      </div>
    </div>
  );
}