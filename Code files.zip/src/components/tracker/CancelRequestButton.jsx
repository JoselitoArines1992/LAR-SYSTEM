import { useState } from "react";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { cancelLeave } from "@/lib/workflow";
import { formatDate } from "@/lib/roles";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function CancelRequestButton({ leave, onDone }) {
  const [busy, setBusy] = useState(false);

  const handleCancel = async () => {
    setBusy(true);
    try {
      await cancelLeave(leave);
      toast.success(`${leave.leave_id} has been cancelled.`);
      await onDone?.();
    } catch (error) {
      toast.error(error?.message ?? "Unable to cancel this request.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <button
          type="button"
          disabled={busy}
          className="inline-flex h-7 items-center gap-1.5 rounded-lg border border-rose-200 bg-rose-50 px-2.5 text-[11px] font-semibold text-rose-700 transition hover:bg-rose-100 disabled:opacity-60"
        >
          {busy && <Loader2 className="h-3 w-3 animate-spin" />}
          Cancel
        </button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Cancel {leave.leave_id}?</AlertDialogTitle>
          <AlertDialogDescription>
            Your {leave.leave_type} request for {formatDate(leave.start_date)} – {formatDate(leave.end_date)} (
            {leave.days_count} day{leave.days_count > 1 ? "s" : ""}) will be withdrawn from the approval chain. This
            cannot be undone — you would need to file a new application.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Keep request</AlertDialogCancel>
          <AlertDialogAction onClick={handleCancel} className="bg-rose-600 hover:bg-rose-700">
            Cancel request
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}