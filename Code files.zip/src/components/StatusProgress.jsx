import { Check, X } from "lucide-react";
import { cn } from "@/lib/utils";

const STEPS = ["Submitted", "Pending UM", "Pending AM", "Final"];

function stageIndex(status) {
  if (status === "Pending UM") return 1;
  if (status === "Pending AM") return 2;
  if (status === "Approved" || status === "Rejected" || status === "Cancelled") return 3;
  return 0;
}

export default function StatusProgress({ status, className }) {
  const current = stageIndex(status);
  const labels = STEPS.map((step, index) => {
    if (index !== 3) return step;
    if (status === "Approved") return "Approved";
    if (status === "Rejected") return "Rejected";
    if (status === "Cancelled") return "Cancelled";
    return "Final";
  });

  return (
    <div className={cn("grid grid-cols-4", className)}>
      {labels.map((label, index) => {
        const reached = index <= current;
        const failed = index === 3 && status === "Rejected";
        const cancelled = index === 3 && status === "Cancelled";
        const filled = reached && !failed && !cancelled;
        return (
          <div key={label} className="flex flex-col items-center">
            <div className="relative flex h-6 w-full items-center justify-center">
              {index > 0 && (
                <span
                  className={cn(
                    "absolute left-0 top-1/2 h-0.5 w-1/2 -translate-y-1/2",
                    index <= current ? "bg-primary/35" : "bg-border",
                  )}
                />
              )}
              {index < labels.length - 1 && (
                <span
                  className={cn(
                    "absolute right-0 top-1/2 h-0.5 w-1/2 -translate-y-1/2",
                    index + 1 <= current ? "bg-primary/35" : "bg-border",
                  )}
                />
              )}
              <span
                className={cn(
                  "relative z-10 grid h-6 w-6 place-items-center rounded-full border text-[10px] font-bold",
                  filled && "border-primary bg-primary text-primary-foreground",
                  failed && "border-rose-500 bg-rose-500 text-white",
                  !filled && !failed && !cancelled && reached && "border-primary/40 bg-card text-primary",
                  !reached && "border-border bg-card text-muted-foreground/60",
                  index === current && !failed && !cancelled && "ring-4 ring-primary/10",
                  cancelled && "border-input bg-secondary text-muted-foreground",
                )}
              >
                {filled ? (
                  <Check className="h-3 w-3" strokeWidth={3.2} />
                ) : failed || cancelled ? (
                  <X className="h-3 w-3" strokeWidth={3.2} />
                ) : (
                  index + 1
                )}
              </span>
            </div>
            <span
              className={cn(
                "mt-2 px-0.5 text-center text-[10px] font-semibold uppercase tracking-[0.07em]",
                failed
                  ? "text-rose-600"
                  : cancelled
                    ? "text-muted-foreground"
                    : reached
                      ? "text-foreground/75"
                      : "text-muted-foreground/60",
              )}
            >
              {label}
            </span>
          </div>
        );
      })}
    </div>
  );
}