import { cn } from "@/lib/utils";

export default function StatCard({ label, value, hint, icon: Icon, tone = "default" }) {
  const navy = tone === "navy";
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-2xl border p-4 transition",
        navy
          ? "lar-navy-gradient border-primary/20 text-primary-foreground shadow-[0_18px_40px_-30px_hsl(var(--brand-navy))]"
          : "border-border bg-card shadow-[0_1px_2px_rgba(15,35,60,0.04)]",
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <p className={cn("text-[11px] font-semibold uppercase tracking-[0.13em]", navy ? "text-white/65" : "text-muted-foreground")}>
          {label}
        </p>
        {Icon && (
          <span className={cn("grid h-7 w-7 place-items-center rounded-lg", navy ? "bg-white/12 text-white" : "bg-secondary text-primary")}>
            <Icon className="h-3.5 w-3.5" />
          </span>
        )}
      </div>
      <p className={cn("mt-3 font-heading text-[28px] font-extrabold leading-none", navy ? "text-white" : "text-primary")}>{value}</p>
      {hint && <p className={cn("mt-2 text-[11.5px] leading-snug", navy ? "text-white/70" : "text-muted-foreground")}>{hint}</p>}
    </div>
  );
}