import { statusMeta } from "@/lib/roles";
import { cn } from "@/lib/utils";

export default function StatusBadge({ status, className, short = false }) {
  const meta = statusMeta(status);
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold ring-1",
        meta.className,
        className,
      )}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current opacity-70" />
      {short ? meta.short : meta.label}
    </span>
  );
}