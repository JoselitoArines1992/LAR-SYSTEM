import { Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeftRight, Check, ChevronDown, LogOut } from "lucide-react";
import { useRole } from "@/lib/RoleContext";
import { roleMeta } from "@/lib/roles";
import RoleBadge from "@/components/RoleBadge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

function initials(name = "") {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();
}

export default function AccountMenu() {
  const { active, employees, signInAs, signOutRole } = useRole();
  const navigate = useNavigate();

  const switchTo = (employee) => {
    signInAs(employee);
    navigate({ to: "/dashboard" });
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          className="flex items-center gap-2.5 rounded-full border border-border bg-card py-1 pl-1 pr-2.5 text-left shadow-sm transition hover:border-primary/30 hover:shadow-md focus:outline-none focus-visible:ring-4 focus-visible:ring-primary/15"
        >
          <span className="grid h-8 w-8 place-items-center rounded-full bg-primary text-[11px] font-bold text-white">
            {active ? initials(active.full_name) : "—"}
          </span>
          <span className="hidden leading-tight sm:block">
            <span className="block max-w-[150px] truncate text-[13px] font-semibold text-foreground">
              {active?.full_name ?? "Select account"}
            </span>
            <span className="block text-[11px] text-muted-foreground">
              {active ? roleMeta(active.role).label : "No portal selected"}
            </span>
          </span>
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-72">
        <DropdownMenuLabel className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
          Switch account
        </DropdownMenuLabel>
        {employees.map((employee) => {
          const isActive = employee.employee_id === active?.employee_id;
          return (
            <DropdownMenuItem
              key={employee.employee_id}
              onSelect={() => switchTo(employee)}
              className="flex cursor-pointer items-start gap-3 py-2.5"
            >
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-secondary text-[11px] font-bold text-primary">
                {initials(employee.full_name)}
              </span>
              <span className="min-w-0 flex-1 leading-tight">
                <span className="flex items-center gap-1.5">
                  <span className="truncate text-[13px] font-semibold">{employee.full_name}</span>
                  {isActive && <Check className="h-3.5 w-3.5 text-emerald-600" />}
                </span>
                <span className="mt-0.5 block truncate text-[11px] text-muted-foreground">
                  {roleMeta(employee.role).label} · {employee.unit_branch}
                </span>
              </span>
            </DropdownMenuItem>
          );
        })}
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild className="cursor-pointer">
          <Link to="/" className="flex items-center gap-2 text-[13px]">
            <ArrowLeftRight className="h-3.5 w-3.5" />
            Open account switcher
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem
          onSelect={() => {
            signOutRole();
            navigate({ to: "/" });
          }}
          className="cursor-pointer text-[13px] text-rose-600 focus:text-rose-700"
        >
          <LogOut className="h-3.5 w-3.5" />
          Sign out of portal
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}