export default function PageHeader({ eyebrow, title, description, actions }) {
  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        {eyebrow && <p className="lar-eyebrow">{eyebrow}</p>}
        <h1 className="mt-2 font-heading text-[26px] font-extrabold leading-tight text-primary sm:text-[30px]">{title}</h1>
        {description && <p className="mt-1.5 max-w-xl text-[13.5px] leading-relaxed text-muted-foreground">{description}</p>}
      </div>
      {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
    </div>
  );
}