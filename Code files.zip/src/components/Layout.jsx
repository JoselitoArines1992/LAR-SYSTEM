import { Link, useLocation } from "@tanstack/react-router";
import { ClipboardCheck, FilePlus2, History, LayoutDashboard, UserRoundCog } from "lucide-react";
import { useRole } from "@/lib/RoleContext";
import RoleBadge from "@/components/RoleBadge";
import AccountMenu from "@/components/AccountMenu";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, roles: ["AO", "UM", "AM"] },
  { to: "/file-leave", label: "File leave", icon: FilePlus2, roles: ["AO"] },
  { to: "/reviews", label: "For review", icon: ClipboardCheck, roles: ["UM", "AM"] },
  { to: "/tracker", label: "Tracker", icon: History, roles: ["AO", "UM", "AM"] },
];

function Brand() {
  return (
    <Link to="/dashboard" className="flex items-center gap-2.5">
      <span className="lar-navy-gradient grid h-9 w-9 place-items-center rounded-xl font-heading text-[15px] font-extrabold text-white shadow-sm">
        L
      </span>
      <span className="leading-none">
        <span className="block font-heading text-[15px] font-extrabold tracking-tight text-primary">LAR-Sys</span>
        <span className="mt-1 block text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
          CARD MRI Rizal Bank
        </span>
      </span>
    </Link>
  );
}

export default function Layout({ children }) {
  const { active } = useRole();
  const location = useLocation();
  const pathname = location.pathname;
  const onSwitcher = pathname === "/";

  const items = active ? NAV_ITEMS.filter((item) => item.roles.includes(active.role)) : [];
  const isActive = (to) => pathname === to || pathname.startsWith(`${to}/`);

  if (!active && !onSwitcher) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b border-border bg-card">
          <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
            <Brand />
            <AccountMenu />
          </div>
        </header>
        <main className="mx-auto flex max-w-md flex-col items-center px-6 py-24 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-2xl bg-secondary text-primary">
            <UserRoundCog className="h-6 w-6" />
          </span>
          <h1 className="mt-6 text-2xl font-bold text-primary">Choose a portal to continue</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Select the Account Officer, Unit Manager, or Area Manager account to open its workspace.
          </p>
          <Link
            to="/"
            className="mt-7 inline-flex h-11 items-center rounded-xl bg-primary px-5 text-sm font-semibold text-white shadow-sm transition hover:bg-primary/90"
          >
            Open account switcher
          </Link>
        </main>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="sticky top-0 z-40 border-b border-border/80 bg-card/85 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-6 px-4 sm:px-6">
          <Brand />
          {active && (
            <nav className="hidden items-center gap-1 md:flex">
              {items.map((item) => {
                const Icon = item.icon;
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    className={cn(
                      "inline-flex items-center gap-2 rounded-lg px-3 py-2 text-[13.5px] font-semibold transition",
                      isActive(item.to)
                        ? "bg-secondary text-primary"
                        : "text-muted-foreground hover:bg-secondary/70 hover:text-foreground",
                    )}
                  >
                    <Icon className="h-4 w-4" strokeWidth={2.2} />
                    {item.label}
                  </Link>
                );
              })}
            </nav>
          )}
          <div className="ml-auto flex items-center gap-2.5">
            {active && <RoleBadge role={active.role} showLabel={false} className="hidden sm:inline-flex" />}
            <AccountMenu />
          </div>
        </div>
      </header>

      <main className={cn("flex-1", active && "pb-24 md:pb-10")}>{children}</main>

      {active && (
        <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-card/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md md:hidden">
          <div className="mx-auto grid max-w-md grid-cols-4">
            {items.map((item) => {
              const Icon = item.icon;
              const highlighted = isActive(item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex flex-col items-center gap-1 py-2.5 text-[10.5px] font-semibold transition",
                    highlighted ? "text-primary" : "text-muted-foreground",
                  )}
                >
                  <Icon className="h-[18px] w-[18px]" strokeWidth={highlighted ? 2.4 : 2} />
                  {item.label}
                </Link>
              );
            })}
          </div>
        </nav>
      )}
    </div>
  );
}