import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { AlertCircle, ArrowRight, Loader2, MapPin, ShieldCheck } from "lucide-react";
import { useRole } from "@/lib/RoleContext";
import { useLeaveData } from "@/hooks/useLeaveData";
import { submitLeaveApplication } from "@/lib/workflow";
import { LEAVE_TYPES, computeDays, formatDate, roleMeta } from "@/lib/roles";
import PageHeader from "@/components/PageHeader";
import RoleBadge from "@/components/RoleBadge";
import RelieverCheck from "@/components/RelieverCheck";

export const Route = createFileRoute("/_authed/file-leave")({
  head: () => ({ meta: [{ title: "File Leave · LAR-Sys" }] }),
  component: FileLeave,
});

const EMPTY_FORM = { leaveType: "", startDate: "", endDate: "", reason: "", relieverId: "" };

function FileLeave() {
  const { active, refresh } = useRole();
  const { leaves, employees } = useLeaveData();
  const navigate = useNavigate();
  const [form, setForm] = useState({ ...EMPTY_FORM, leaveType: LEAVE_TYPES[0] });
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (!active) return null;

  if (active.role !== "AO") {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <h1 className="font-heading text-2xl font-bold text-primary">Filing is an Account Officer action</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Switch to the Account Officer account from the profile menu to file a new leave application.
        </p>
      </div>
    );
  }

  const days = computeDays(form.startDate, form.endDate);
  const balance = active.leave_balance ?? 0;
  const exceedsBalance = days > balance;
  const colleagues = employees.filter(
    (employee) => employee.unit_branch === active.unit_branch && employee.employee_id !== active.employee_id && employee.role === "AO",
  );
  const reliever = colleagues.find((employee) => employee.employee_id === form.relieverId) ?? null;
  const unitManager = employees.find((e) => e.role === "UM" && e.unit_branch === active.unit_branch) ?? null;
  const areaManager = employees.find((e) => e.role === "AM" && e.cluster === active.cluster) ?? null;

  const update = (patch) => setForm((current) => ({ ...current, ...patch }));

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    if (!form.startDate || !form.endDate) return setError("Select both the start and end date of your leave.");
    if (!days) return setError("The end date must fall on or after the start date.");
    if (exceedsBalance) return setError(`You only have ${balance} leave credit(s) left.`);
    if (form.reason.trim().length < 10) return setError("Please provide a reason with at least 10 characters.");
    if (!reliever) return setError("Assign a branch reliever before submitting.");

    setSubmitting(true);
    try {
      const leave = await submitLeaveApplication({
        employee: active,
        leaveType: form.leaveType,
        startDate: form.startDate,
        endDate: form.endDate,
        reason: form.reason.trim(),
        reliever,
      });
      await refresh();
      toast.success("Application filed — routed to your Unit Manager for recommendation.");
      navigate({ to: "/request/$leaveId", params: { leaveId: leave.leave_id } });
    } catch (submitError) {
      setError(submitError.message ?? "Unable to file the leave application.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-7 sm:px-6 sm:py-10">
      <PageHeader
        eyebrow="Account Officer Portal"
        title="File a leave application"
        description="Select the leave type and inclusive dates, assign a mandatory branch reliever, then submit for Unit Manager recommendation."
        actions={<RoleBadge role="AO" />}
      />

      <form onSubmit={handleSubmit} className="mt-6 grid gap-5 lg:grid-cols-[1.5fr_1fr]">
        <div className="lar-panel p-5 sm:p-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="lar-field-label" htmlFor="leaveType">
                Leave type
              </label>
              <select
                id="leaveType"
                className="lar-field"
                value={form.leaveType}
                onChange={(event) => update({ leaveType: event.target.value })}
              >
                {LEAVE_TYPES.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="lar-field-label" htmlFor="startDate">
                Start date
              </label>
              <input
                id="startDate"
                type="date"
                className="lar-field"
                value={form.startDate}
                onChange={(event) => update({ startDate: event.target.value })}
              />
            </div>
            <div>
              <label className="lar-field-label" htmlFor="endDate">
                End date
              </label>
              <input
                id="endDate"
                type="date"
                className="lar-field"
                min={form.startDate || undefined}
                value={form.endDate}
                onChange={(event) => update({ endDate: event.target.value })}
              />
            </div>

            <div className="sm:col-span-2">
              <label className="lar-field-label" htmlFor="reliever">
                Branch reliever <span className="text-rose-600">*</span>
              </label>
              <select
                id="reliever"
                className="lar-field"
                value={form.relieverId}
                onChange={(event) => update({ relieverId: event.target.value })}
              >
                <option value="">Select the officer covering your field center…</option>
                {colleagues.map((employee) => (
                  <option key={employee.employee_id} value={employee.employee_id}>
                    {employee.full_name} · {employee.employee_id}
                  </option>
                ))}
              </select>
              <p className="mt-1.5 text-[11.5px] leading-relaxed text-muted-foreground">
                Assignment is mandatory — your Unit Manager verifies this reliever against center meeting schedules.
              </p>
            </div>

            <div className="sm:col-span-2">
              <label className="lar-field-label" htmlFor="reason">
                Reason for leave
              </label>
              <textarea
                id="reason"
                rows={4}
                className="w-full rounded-xl border border-input bg-card px-3.5 py-3 text-sm shadow-sm transition placeholder:text-muted-foreground/70 focus:border-primary/40 focus:outline-none focus:ring-4 focus:ring-primary/10"
                placeholder="Describe the reason and any coverage instructions for your reliever…"
                value={form.reason}
                onChange={(event) => update({ reason: event.target.value })}
              />
            </div>
          </div>

          {error && (
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-2.5">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-rose-600" />
              <p className="text-[12.5px] font-medium text-rose-800">{error}</p>
            </div>
          )}

          <div className="mt-5 flex flex-col-reverse gap-2.5 border-t border-border/70 pt-5 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-[11.5px] text-muted-foreground">
              Filing sets the status to <span className="font-semibold text-foreground">Pending UM Recommendation</span>.
            </p>
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-primary px-5 text-[13.5px] font-semibold text-white shadow-sm transition hover:bg-primary/90 disabled:opacity-60"
            >
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              Submit for recommendation
              {!submitting && <ArrowRight className="h-4 w-4" />}
            </button>
          </div>
        </div>

        <aside className="space-y-4">
          <div className="lar-panel p-5">
            <h2 className="text-[13px] font-bold uppercase tracking-[0.12em] text-muted-foreground">Request summary</h2>
            <dl className="mt-4 space-y-3">
              <div className="flex items-baseline justify-between gap-3">
                <dt className="text-[12.5px] text-muted-foreground">Days requested</dt>
                <dd className="font-heading text-lg font-extrabold text-primary">{days || "—"}</dd>
              </div>
              <div className="flex items-baseline justify-between gap-3">
                <dt className="text-[12.5px] text-muted-foreground">Available credits</dt>
                <dd className="text-[13px] font-semibold text-foreground">{balance} day(s)</dd>
              </div>
              <div className="flex items-baseline justify-between gap-3 border-t border-border/70 pt-3">
                <dt className="text-[12.5px] text-muted-foreground">Balance after approval</dt>
                <dd className={`text-[13px] font-semibold ${exceedsBalance ? "text-rose-600" : "text-emerald-700"}`}>
                  {exceedsBalance ? "Insufficient" : `${Math.max(0, balance - days)} day(s)`}
                </dd>
              </div>
            </dl>
            {form.startDate && form.endDate && (
              <p className="mt-3 rounded-lg bg-secondary/60 px-3 py-2 text-[11.5px] text-muted-foreground">
                {formatDate(form.startDate)} → {formatDate(form.endDate)}
              </p>
            )}
          </div>

          <div className="lar-panel p-5">
            <h2 className="text-[13px] font-bold uppercase tracking-[0.12em] text-muted-foreground">Reliever check</h2>
            <div className="mt-3">
              <RelieverCheck
                relieverId={form.relieverId}
                relieverName={reliever?.full_name}
                startDate={form.startDate}
                endDate={form.endDate}
                leaves={leaves}
              />
            </div>
          </div>

          <div className="lar-panel p-5">
            <h2 className="text-[13px] font-bold uppercase tracking-[0.12em] text-muted-foreground">Routing preview</h2>
            <ul className="mt-3 space-y-3">
              <li className="flex items-start gap-2.5">
                <RoleBadge role="UM" showLabel={false} size="sm" />
                <div>
                  <p className="text-[12.5px] font-semibold text-foreground">{unitManager?.full_name ?? "Unassigned"}</p>
                  <p className="text-[11px] text-muted-foreground">Level‑1 recommendation · {active.unit_branch}</p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <RoleBadge role="AM" showLabel={false} size="sm" />
                <div>
                  <p className="text-[12.5px] font-semibold text-foreground">{areaManager?.full_name ?? "Unassigned"}</p>
                  <p className="text-[11px] text-muted-foreground">Level‑2 final approval · {active.cluster}</p>
                </div>
              </li>
            </ul>
            <div className="mt-4 flex items-center gap-2 rounded-lg bg-secondary/60 px-3 py-2 text-[11px] text-muted-foreground">
              <ShieldCheck className="h-3.5 w-3.5 text-primary" />
              Sequential — no level can be skipped.
            </div>
            <div className="mt-2 flex items-center gap-2 rounded-lg bg-secondary/60 px-3 py-2 text-[11px] text-muted-foreground">
              <MapPin className="h-3.5 w-3.5 text-primary" />
              {roleMeta(active.role).label} · {active.unit_branch}
            </div>
          </div>
        </aside>
      </form>
    </div>
  );
}