import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { CheckCircle2, ClipboardList } from "lucide-react";
import { useRole } from "@/lib/RoleContext";
import { useLeaveData } from "@/hooks/useLeaveData";
import { awaitingMyAction, inScope } from "@/lib/workflow";
import { roleMeta } from "@/lib/roles";
import PageHeader from "@/components/PageHeader";
import RoleBadge from "@/components/RoleBadge";
import ReviewRow from "@/components/ReviewRow";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authed/reviews")({
  head: () => ({ meta: [{ title: "Review Queue · LAR-Sys" }] }),
  component: Reviews,
});

const TABS = [
  { key: "queue", label: "Awaiting my action" },
  { key: "all", label: "All in my scope" },
];

function Reviews() {
  const { active } = useRole();
  const { leaves, loading } = useLeaveData();
  const [tab, setTab] = useState("queue");

  if (!active) return null;

  if (active.role === "AO") {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <h1 className="font-heading text-2xl font-bold text-primary">Review actions belong to UM and AM</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Sign in as the Unit Manager or Area Manager to act on pending leave applications.
        </p>
      </div>
    );
  }

  const scoped = leaves.filter((leave) => inScope(leave, active));
  const queue = scoped.filter((leave) => awaitingMyAction(leave, active));
  const list = tab === "queue" ? queue : scoped;

  return (
    <div className="mx-auto max-w-6xl px-4 py-7 sm:px-6 sm:py-10">
      <PageHeader
        eyebrow={roleMeta(active.role).portal}
        title={active.role === "UM" ? "Unit review queue" : "Cluster approval queue"}
        description={
          active.role === "UM"
            ? `${active.unit_branch} · verify reliever availability against center meeting schedules before recommending.`
            : `${active.cluster} · only requests already endorsed by a Unit Manager appear here.`
        }
        actions={<RoleBadge role={active.role} />}
      />

      <div className="mt-5 flex w-full max-w-sm rounded-xl border border-border bg-card p-1 shadow-sm">
        {TABS.map((item) => (
          <button
            key={item.key}
            type="button"
            onClick={() => setTab(item.key)}
            className={cn(
              "flex-1 rounded-lg px-3 py-2 text-[12.5px] font-semibold transition",
              tab === item.key ? "bg-primary text-white shadow-sm" : "text-muted-foreground hover:text-foreground",
            )}
          >
            {item.label}
            <span className={cn("ml-1.5 rounded-full px-1.5 py-0.5 text-[10px]", tab === item.key ? "bg-primary-foreground/20" : "bg-secondary")}>
              {item.key === "queue" ? queue.length : scoped.length}
            </span>
          </button>
        ))}
      </div>

      <section className="lar-panel mt-4 overflow-hidden">
        <div className="hidden grid-cols-[1.6fr_1.1fr_0.5fr_1fr_auto] gap-4 border-b border-border/80 bg-secondary/40 px-4 py-2.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-muted-foreground md:grid">
          <span>Filer</span>
          <span>Inclusive dates</span>
          <span>Days</span>
          <span>Reliever</span>
          <span className="text-right">Status</span>
        </div>

        {loading ? (
          <div className="space-y-3 p-4">
            {[0, 1, 2].map((key) => (
              <div key={key} className="h-12 animate-pulse rounded-lg bg-secondary/70" />
            ))}
          </div>
        ) : list.length === 0 ? (
          <div className="flex flex-col items-center px-6 py-16 text-center">
            <span className="grid h-12 w-12 place-items-center rounded-full bg-emerald-50 text-emerald-600">
              <CheckCircle2 className="h-6 w-6" />
            </span>
            <p className="mt-3 text-[13.5px] font-semibold text-foreground">
              {tab === "queue" ? "Nothing awaiting your action" : "No applications in your scope yet"}
            </p>
            <p className="mt-1 max-w-sm text-[12px] text-muted-foreground">
              {tab === "queue"
                ? "All requests at your level have been acted on. New filings appear here automatically."
                : "Filings from your unit will show up here once submitted."}
            </p>
          </div>
        ) : (
          <div>
            {list.map((leave) => (
              <ReviewRow key={leave.id} leave={leave} actionable={awaitingMyAction(leave, active)} />
            ))}
          </div>
        )}
      </section>

      <div className="mt-4 flex items-start gap-2.5 rounded-xl border border-border bg-card px-4 py-3">
        <ClipboardList className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
        <p className="text-[11.5px] leading-relaxed text-muted-foreground">
          {active.role === "UM"
            ? "Recommending a request moves it to Pending AM Approval. Rejecting ends the workflow and notifies the Account Officer."
            : "Approving a request releases the leave and deducts the corresponding credits from the filer's balance."}
        </p>
      </div>
    </div>
  );
}