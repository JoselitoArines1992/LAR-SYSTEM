import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight, Inbox } from "lucide-react";
import { useRole } from "@/lib/RoleContext";
import { useLeaveData, workflowFor } from "@/hooks/useLeaveData";
import { canCancelLeave, inScope } from "@/lib/workflow";
import { formatDate, roleMeta } from "@/lib/roles";
import PageHeader from "@/components/PageHeader";
import RoleBadge from "@/components/RoleBadge";
import StatusBadge from "@/components/StatusBadge";
import StatusProgress from "@/components/StatusProgress";
import CancelRequestButton from "@/components/tracker/CancelRequestButton";
import LeaveFilterChips from "@/components/LeaveFilterChips";
import { countFor, matchesFilter } from "@/lib/leaveFilters";

export const Route = createFileRoute("/_authed/tracker")({
  head: () => ({ meta: [{ title: "Live Status Tracker · LAR-Sys" }] }),
  component: Tracker,
});

const FILTERS = [
  { key: "all", label: "All" },
  { key: "pending", label: "Pending" },
  { key: "recommended", label: "Recommended" },
  { key: "approved", label: "Approved" },
  { key: "Rejected", label: "Rejected" },
  { key: "Cancelled", label: "Cancelled" },
];

function Tracker() {
  const { active } = useRole();
  const { leaves, workflows, loading, reload } = useLeaveData();
  const [filter, setFilter] = useState("all");

  if (!active) return null;

  const scoped =
    active.role === "AO" ? leaves.filter((leave) => leave.employee_id === active.employee_id) : leaves.filter((leave) => inScope(leave, active));
  const filtered = scoped.filter((leave) => matchesFilter(leave, filter));
  const filters = FILTERS.map((item) => ({ ...item, count: countFor(scoped, item.key) }));

  return (
    <div className="mx-auto max-w-6xl px-4 py-7 sm:px-6 sm:py-10">
      <PageHeader
        eyebrow={roleMeta(active.role).portal}
        title="Live status tracker"
        description={
          active.role === "AO"
            ? "Follow each filing through Unit Manager recommendation and Area Manager approval."
            : `Every filing inside ${active.role === "UM" ? active.unit_branch : active.cluster}, with its exact position in the chain.`
        }
        actions={<RoleBadge role={active.role} />}
      />

      <LeaveFilterChips filters={filters} value={filter} onChange={setFilter} className="mt-5" />

      <div className="mt-4 grid gap-3.5 lg:grid-cols-2">
        {loading ? (
          [0, 1, 2, 3].map((key) => <div key={key} className="h-40 animate-pulse rounded-2xl bg-secondary/60" />)
        ) : filtered.length === 0 ? (
          <div className="lar-panel col-span-full flex flex-col items-center px-6 py-16 text-center">
            <span className="grid h-12 w-12 place-items-center rounded-full bg-secondary text-primary">
              <Inbox className="h-6 w-6" />
            </span>
            <p className="mt-3 text-[13.5px] font-semibold text-foreground">No applications in this view</p>
            <p className="mt-1 max-w-sm text-[12px] text-muted-foreground">
              {active.role === "AO" ? "File a leave application to start tracking its routing." : "Adjust the filter to see other filings."}
            </p>
          </div>
        ) : (
          filtered.map((leave) => {
            const workflow = workflowFor(workflows, leave.leave_id);
            return (
              <div
                key={leave.id}
                className="lar-panel group p-4 transition hover:-translate-y-0.5 hover:shadow-[0_20px_40px_-30px_hsl(var(--brand-navy))]"
              >
                <Link to="/request/$leaveId" params={{ leaveId: leave.leave_id }} className="block">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[10.5px] text-muted-foreground">{leave.leave_id}</span>
                      <span className="h-1 w-1 rounded-full bg-muted-foreground/40" />
                      <span className="truncate text-[11px] text-muted-foreground">{leave.employee_name}</span>
                    </div>
                    <p className="mt-1 truncate text-[14px] font-bold text-foreground">{leave.leave_type}</p>
                    <p className="mt-0.5 text-[11.5px] text-muted-foreground">
                      {formatDate(leave.start_date)} – {formatDate(leave.end_date)} · {leave.days_count} day
                      {leave.days_count > 1 ? "s" : ""}
                    </p>
                  </div>
                  <StatusBadge status={leave.overall_status} short />
                </div>

                <StatusProgress status={leave.overall_status} className="mt-4" />
                </Link>

                <div className="mt-3 flex items-center justify-between border-t border-border/70 pt-3">
                  <span className="truncate text-[11px] text-muted-foreground">
                    Reliever: {leave.reliever_name ?? "—"}
                    {workflow?.um_recommendation === "Recommended" && leave.overall_status === "Pending AM"
                      ? ` · Endorsed by ${workflow.um_name ?? "UM"}`
                      : ""}
                  </span>
                  <div className="flex shrink-0 items-center gap-2">
                    {canCancelLeave(leave, active) && <CancelRequestButton leave={leave} onDone={reload} />}
                    <Link to="/request/$leaveId" params={{ leaveId: leave.leave_id }}>
                      <ArrowUpRight className="h-3.5 w-3.5 text-muted-foreground transition group-hover:text-primary" />
                    </Link>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}