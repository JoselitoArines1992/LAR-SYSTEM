import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Building2, CalendarDays, MessageSquareText, UserRound } from "lucide-react";
import { useRole } from "@/lib/RoleContext";
import { useLeaveData, workflowFor } from "@/hooks/useLeaveData";
import { formatDate, formatDateTime } from "@/lib/roles";
import StatusBadge from "@/components/StatusBadge";
import StatusProgress from "@/components/StatusProgress";
import RelieverCheck from "@/components/RelieverCheck";
import RequestTimeline from "@/components/request/RequestTimeline";
import ActionPanel from "@/components/request/ActionPanel";
import CancelRequestButton from "@/components/tracker/CancelRequestButton";
import { canCancelLeave } from "@/lib/workflow";

export const Route = createFileRoute("/_authed/request/$leaveId")({
  head: () => ({ meta: [{ title: "Leave Request · LAR-Sys" }] }),
  component: RequestDetail,
});

function Meta({ label, value, icon: Icon }) {
  return (
    <div className="flex items-start gap-2.5">
      {Icon && (
        <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-secondary text-primary">
          <Icon className="h-3.5 w-3.5" />
        </span>
      )}
      <div className="min-w-0">
        <p className="text-[10px] font-semibold uppercase tracking-[0.11em] text-muted-foreground">{label}</p>
        <p className="mt-0.5 truncate text-[12.5px] font-semibold text-foreground">{value}</p>
      </div>
    </div>
  );
}

function RequestDetail() {
  const { leaveId } = Route.useParams();
  const { active } = useRole();
  const { leaves, workflows, loading, reload } = useLeaveData();

  if (!active) return null;

  if (loading) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-16">
        <div className="h-40 animate-pulse rounded-2xl bg-secondary/60" />
      </div>
    );
  }

  const leave = leaves.find((item) => item.leave_id === leaveId);
  const workflow = leave ? workflowFor(workflows, leave.leave_id) : null;

  if (!leave) {
    return (
      <div className="mx-auto max-w-md px-4 py-24 text-center">
        <h1 className="font-heading text-xl font-bold text-primary">Application not found</h1>
        <p className="mt-2 text-[13px] text-muted-foreground">This leave reference does not exist in the current records.</p>
        <Link to="/tracker" className="mt-6 inline-flex h-10 items-center rounded-xl bg-primary px-4 text-[13px] font-semibold text-white">
          Back to tracker
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 sm:px-6 sm:py-10">
      <Link to="/tracker" className="inline-flex items-center gap-1.5 text-[12px] font-semibold text-muted-foreground transition hover:text-primary">
        <ArrowLeft className="h-3.5 w-3.5" /> Live status tracker
      </Link>

      <div className="lar-panel mt-3 p-5 sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-[11px] text-muted-foreground">{leave.leave_id}</span>
              <span className="h-1 w-1 rounded-full bg-muted-foreground/40" />
              <span className="text-[11px] text-muted-foreground">{leave.unit_branch}</span>
            </div>
            <h1 className="mt-1.5 font-heading text-[24px] font-extrabold leading-tight text-primary sm:text-[27px]">
              {leave.leave_type}
            </h1>
            <p className="mt-1 text-[12.5px] text-muted-foreground">
              {formatDate(leave.start_date)} – {formatDate(leave.end_date)} · {leave.days_count} day
              {leave.days_count > 1 ? "s" : ""} · filed {formatDateTime(leave.filed_at)}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={leave.overall_status} />
            {canCancelLeave(leave, active) && <CancelRequestButton leave={leave} onDone={reload} />}
          </div>
        </div>

        <StatusProgress status={leave.overall_status} className="mt-6" />

        <div className="mt-6 grid gap-4 border-t border-border/70 pt-5 sm:grid-cols-2 lg:grid-cols-4">
          <Meta label="Filed by" value={leave.employee_name} icon={UserRound} />
          <Meta label="Unit / Cluster" value={`${leave.unit_branch} · ${leave.cluster ?? "—"}`} icon={Building2} />
          <Meta label="Reliever" value={leave.reliever_name ?? "—"} icon={CalendarDays} />
          <Meta label="Unit Manager" value={leave.um_name ?? "—"} icon={UserRound} />
        </div>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1.25fr_1fr]">
        <div className="space-y-4">
          <section className="lar-panel p-5">
            <div className="flex items-center gap-2">
              <MessageSquareText className="h-4 w-4 text-primary" />
              <h2 className="text-[13px] font-bold uppercase tracking-[0.11em] text-muted-foreground">Reason for leave</h2>
            </div>
            <p className="mt-3 text-[13px] leading-relaxed text-foreground/85">{leave.reason || "No reason provided."}</p>
          </section>

          <section className="lar-panel p-5">
            <h2 className="text-[13px] font-bold uppercase tracking-[0.11em] text-muted-foreground">Reliever availability</h2>
            <div className="mt-3">
              <RelieverCheck
                relieverId={leave.reliever_id}
                relieverName={leave.reliever_name}
                startDate={leave.start_date}
                endDate={leave.end_date}
                leaves={leaves.filter((item) => item.leave_id !== leave.leave_id)}
              />
            </div>
          </section>
        </div>

        <div className="space-y-4">
          <section className="lar-panel p-5">
            <h2 className="text-[13px] font-bold uppercase tracking-[0.11em] text-muted-foreground">Approval workflow</h2>
            <div className="mt-4">
              <RequestTimeline leave={leave} workflow={workflow} />
            </div>
          </section>

          <ActionPanel leave={leave} workflow={workflow} onDone={reload} />
        </div>
      </div>
    </div>
  );
}