import { useState } from "react";
import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import {
  ArrowUpRight,
  CalendarDays,
  ClipboardCheck,
  FilePlus2,
  Inbox,
  Layers,
  ShieldCheck,
  Wallet,
} from "lucide-react";
import { useRole } from "@/lib/RoleContext";
import { useLeaveData } from "@/hooks/useLeaveData";
import { awaitingMyAction, inScope } from "@/lib/workflow";
import { formatDate, roleMeta } from "@/lib/roles";
import RoleBadge from "@/components/RoleBadge";
import StatCard from "@/components/StatCard";
import LeaveRow from "@/components/LeaveRow";
import LeaveFilterChips from "@/components/LeaveFilterChips";
import { countFor, matchesFilter } from "@/lib/leaveFilters";


export const Route = createFileRoute("/_authed/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard · LAR-Sys" }] }),
  component: Dashboard,
});

const GREETING = () => {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
};

function Dashboard() {
  const { active, loading: roleLoading } = useRole();
  const { leaves, loading } = useLeaveData();
  const navigate = useNavigate();
  const [filter, setFilter] = useState("pending");

  if (roleLoading) {
    return <div className="mx-auto max-w-6xl px-4 py-16 text-center text-sm text-muted-foreground">Loading workspace…</div>;
  }

  if (!active) {
    return (
      <div className="mx-auto max-w-md px-4 py-16 text-center">
        <h1 className="font-heading text-xl font-bold text-primary">No employee profile linked</h1>
        <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">
          This login isn’t connected to an employee record yet. Pick a portal to continue.
        </p>
        <Link
          to="/"
          className="mt-5 inline-flex h-11 items-center gap-2 rounded-xl bg-primary px-4 text-[13px] font-semibold text-white hover:bg-primary/90"
        >
          Choose a portal
          <ArrowUpRight className="h-4 w-4" />
        </Link>
      </div>
    );
  }

  const meta = roleMeta(active.role);
  const myLeaves = leaves.filter((leave) => leave.employee_id === active.employee_id);
  const scopeLeaves = leaves.filter((leave) => inScope(leave, active));
  const pendingUm = scopeLeaves.filter((leave) => leave.overall_status === "Pending UM");
  const pendingAm = scopeLeaves.filter((leave) => leave.overall_status === "Pending AM");
  const approved = scopeLeaves.filter((leave) => leave.overall_status === "Approved");
  const rejected = scopeLeaves.filter((leave) => leave.overall_status === "Rejected");
  const queue = leaves.filter((leave) => awaitingMyAction(leave, active));
  const myInFlight = myLeaves.filter(
    (leave) => leave.overall_status === "Pending UM" || leave.overall_status === "Pending AM",
  );
  const panelBase = active.role === "AO" ? myLeaves : scopeLeaves;
  const panelRows = panelBase.filter((leave) => matchesFilter(leave, filter));
  const panelFilters = [
    { key: "pending", label: "Pending", count: countFor(panelBase, "pending") },
    { key: "recommended", label: "Recommended", count: countFor(panelBase, "recommended") },
    { key: "approved", label: "Approved", count: countFor(panelBase, "approved") },
  ];
  const daysCommitted = approved.reduce((sum, leave) => sum + (leave.days_count ?? 0), 0);
  const firstName = active.full_name.split(" ")[0];

  const cards =
    active.role === "AO"
      ? [
          { label: "Leave credits left", value: `${active.leave_balance ?? 0}d`, hint: "Remaining for the year", icon: Wallet, tone: "navy" },
          { label: "My pending filings", value: myInFlight.length, hint: "Routing through UM / AM", icon: Inbox },
          { label: "Approved this year", value: approved.length, hint: `${daysCommitted} day(s) released`, icon: ShieldCheck },
          { label: "Awaiting action", value: pendingUm.length + pendingAm.length, hint: "Across your unit", icon: ClipboardCheck },
        ]
      : active.role === "UM"
        ? [
            { label: "Pending my recommendation", value: queue.length, hint: "Level‑1 review required", icon: ClipboardCheck },
            { label: "Unit filings in flight", value: pendingUm.length + pendingAm.length, hint: active.unit_branch, icon: Layers },
            { label: "Cluster approvals", value: approved.length, hint: "Cleared by the Area Manager", icon: ShieldCheck },
            { label: "My leave credits", value: `${active.leave_balance ?? 0}d`, hint: "Personal balance", icon: Wallet, tone: "navy" },
          ]
        : [
            { label: "Pending my approval", value: queue.length, hint: "Level‑2 final approval", icon: ClipboardCheck },
            { label: "Cluster approvals released", value: approved.length, hint: active.cluster, icon: ShieldCheck },
            { label: "Rejected filings", value: rejected.length, hint: "Returned to the filer", icon: Inbox },
            { label: "My leave credits", value: `${active.leave_balance ?? 0}d`, hint: "Personal balance", icon: Wallet, tone: "navy" },
          ];

  const recent = (active.role === "AO" ? myLeaves : scopeLeaves).slice(0, 5);
  const primaryAction =
    active.role === "AO"
      ? { label: "File leave application", to: "/file-leave", icon: FilePlus2 }
      : { label: "Open review queue", to: "/reviews", icon: ClipboardCheck };
  const PrimaryIcon = primaryAction.icon;

  return (
    <div className="mx-auto max-w-6xl px-4 py-7 sm:px-6 sm:py-10">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <p className="lar-eyebrow">{meta.portal}</p>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.1em] text-emerald-700 ring-1 ring-emerald-200">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" /> Live
            </span>
          </div>
          <h1 className="mt-2 font-heading text-[26px] font-extrabold leading-tight text-primary sm:text-[30px]">
            {GREETING()}, {firstName}
          </h1>
          <p className="mt-1.5 max-w-xl text-[13.5px] leading-relaxed text-muted-foreground">
            {active.role === "AO" && `${active.unit_branch} · every filing routes to your Unit Manager before the Area Manager sees it.`}
            {active.role === "UM" && `${active.unit_branch} · verify reliever coverage before endorsing to ${active.cluster}.`}
            {active.role === "AM" && `${active.cluster} · final approvals deduct leave credits automatically.`}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <RoleBadge role={active.role} />
          <Link
            to={primaryAction.to}
            className="inline-flex h-10 items-center gap-2 rounded-xl bg-primary px-4 text-[13px] font-semibold text-white shadow-sm transition hover:bg-primary/90"
          >
            <PrimaryIcon className="h-4 w-4" />
            <span className="hidden sm:inline">{primaryAction.label}</span>
            <span className="sm:hidden">Action</span>
            <ArrowUpRight className="h-3.5 w-3.5 opacity-70" />
          </Link>
        </div>
      </div>

      <div className="mt-6 grid gap-3.5 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((card) => (
          <StatCard key={card.label} {...card} />
        ))}
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-[1.55fr_1fr]">
        <section className="lar-panel overflow-hidden">
          <div className="flex items-center justify-between border-b border-border/80 px-4 py-3.5">
            <div>
              <h2 className="text-[14px] font-bold text-foreground">
                {active.role === "AO" ? "My active filings" : "Leave requests"}
              </h2>
              <p className="mt-0.5 text-[11.5px] text-muted-foreground">
                {active.role === "AO" ? "Live routing status of your requests" : `${panelRows.length} request(s) shown`}
              </p>
            </div>
            <Link to={active.role === "AO" ? "/tracker" : "/reviews"} className="text-[12px] font-semibold text-primary hover:underline">
              View all
            </Link>
          </div>

          <div className="border-b border-border/80 px-4 py-3">
            <LeaveFilterChips filters={panelFilters} value={filter} onChange={setFilter} />
          </div>

          {loading ? (
            <div className="space-y-3 p-4">
              {[0, 1, 2].map((key) => (
                <div key={key} className="h-12 animate-pulse rounded-lg bg-secondary/70" />
              ))}
            </div>
          ) : panelRows.length === 0 ? (
            <div className="flex flex-col items-center px-6 py-12 text-center">
              <span className="grid h-11 w-11 place-items-center rounded-full bg-secondary text-primary">
                <CalendarDays className="h-5 w-5" />
              </span>
              <p className="mt-3 text-[13px] font-semibold text-foreground">
                {active.role === "AO" ? "No filings in flight" : "Your queue is clear"}
              </p>
              <p className="mt-1 max-w-xs text-[12px] text-muted-foreground">
                {active.role === "AO"
                  ? "File a leave application and it will appear here as it routes."
                  : "New requests appear here the moment they reach your level."}
              </p>
            </div>
          ) : (
            <div className="divide-y divide-border/70">
              {panelRows.slice(0, 5).map((leave) => (
                <LeaveRow key={leave.id} leave={leave} />
              ))}
            </div>
          )}
        </section>

        <aside className="space-y-4">
          <div className="lar-panel p-4">
            <div className="flex items-start justify-between">
              <div>
                <p className="lar-eyebrow">Leave balance</p>
                <p className="mt-2 font-heading text-[38px] font-extrabold leading-none text-primary">
                  {active.leave_balance ?? 0}
                  <span className="ml-1 text-[13px] font-semibold text-muted-foreground">days</span>
                </p>
              </div>
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-secondary text-primary">
                <Wallet className="h-4 w-4" />
              </span>
            </div>
            <div className="mt-4 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full rounded-full bg-gold transition-all"
                style={{ width: `${Math.min(100, ((active.leave_balance ?? 0) / 20) * 100)}%` }}
              />
            </div>
            <p className="mt-2 text-[11px] text-muted-foreground">Out of a 20-day annual allocation</p>
          </div>

          <div className="lar-panel p-4">
            <p className="lar-eyebrow">Routing chain</p>
            <ul className="mt-3 space-y-2.5">
              {[
                { key: "AO", value: `${active.role === "AO" ? "You" : "Account Officer"} files` },
                { key: "UM", value: `${active.unit_branch}` },
                { key: "AM", value: `${active.cluster}` },
              ].map((step) => (
                <li key={step.key} className="flex items-center gap-2.5">
                  <RoleBadge role={step.key} showLabel={false} size="sm" />
                  <span className="text-[12px] text-muted-foreground">{step.value}</span>
                </li>
              ))}
            </ul>
            <p className="mt-3 border-t border-border/70 pt-3 text-[11px] leading-relaxed text-muted-foreground">
              Requests can only advance one level at a time — the Area Manager never sees a filing the Unit Manager has not
              endorsed.
            </p>
          </div>
        </aside>
      </div>

      <section className="lar-panel mt-6 overflow-hidden">
        <div className="flex items-center justify-between border-b border-border/80 px-4 py-3.5">
          <h2 className="text-[14px] font-bold text-foreground">Recent applications</h2>
          <button
            type="button"
            onClick={() => navigate({ to: "/tracker" })}
            className="text-[12px] font-semibold text-primary hover:underline"
          >
            Open tracker
          </button>
        </div>
        {recent.length === 0 ? (
          <p className="px-4 py-8 text-center text-[12.5px] text-muted-foreground">No leave activity yet.</p>
        ) : (
          <div className="divide-y divide-border/70">
            {recent.map((leave) => (
              <div key={leave.id} className="flex items-center gap-2">
                <div className="min-w-0 flex-1">
                  <LeaveRow leave={leave} />
                </div>
                <div className="hidden shrink-0 pr-4 text-right text-[11px] text-muted-foreground md:block">
                  Filed {formatDate(leave.filed_at)}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}