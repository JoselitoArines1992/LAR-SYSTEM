import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ArrowRight, Check, ShieldCheck, Sparkles } from "lucide-react";
import { useEffect, useState } from "react";
import { useRole } from "@/lib/RoleContext";
import { ROLE_ORDER, roleMeta } from "@/lib/roles";
import RoleBadge from "@/components/RoleBadge";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authed/")({
  head: () => ({
    meta: [
      { title: "Account Switcher · LAR-Sys | CARD MRI Rizal Bank" },
      {
        name: "description",
        content:
          "Choose the Account Officer, Unit Manager, or Area Manager portal to run the sequential three-role leave workflow.",
      },
    ],
  }),
  component: AccountSwitcher,
});

const WORKFLOW_STEPS = [
  {
    title: "Account Officer files",
    body: "Leave type, inclusive dates, reason, and a mandatory branch reliever — validated against remaining leave credits.",
  },
  {
    title: "Unit Manager recommends",
    body: "The immediate supervisor reviews reliever availability against center meeting schedules, then endorses with remarks.",
  },
  {
    title: "Area Manager approves",
    body: "Final approval is granted at cluster level, and the corresponding leave credits are deducted automatically.",
  },
];

function initials(name = "") {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();
}

function AccountSwitcher() {
  const { employees, active, signInAs, loading } = useRole();
  const navigate = useNavigate();
  const [selectedId, setSelectedId] = useState(active?.employee_id ?? null);

  const fallback = active ?? employees.find((employee) => employee.role === "AO") ?? employees[0] ?? null;

  useEffect(() => {
    if (!selectedId && fallback) setSelectedId(fallback.employee_id);
  }, [selectedId, fallback]);

  // The dashboard is the first screen after sign-in; this picker only appears for
  // a login that has no linked employee record yet.
  useEffect(() => {
    if (!loading && active) navigate({ to: "/dashboard", replace: true });
  }, [loading, active, navigate]);

  const selected = employees.find((employee) => employee.employee_id === selectedId) ?? null;
  const primaryAccounts = ROLE_ORDER.map((role) => employees.find((employee) => employee.role === role)).filter(
    Boolean,
  );

  const enterPortal = () => {
    if (!selected) return;
    signInAs(selected);
    navigate({ to: "/dashboard" });
  };

  if (loading || active) {
    return (
      <div className="mx-auto max-w-6xl px-4 py-16 text-center text-sm text-muted-foreground">
        Opening your dashboard…
      </div>
    );
  }

  return (
    <div className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(120%_90%_at_85%_-10%,hsl(var(--accent))_0%,transparent_55%),radial-gradient(90%_70%_at_-10%_0%,hsl(var(--muted))_0%,transparent_45%)]" />
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-16">
        <div className="grid items-start gap-10 lg:grid-cols-[1.02fr_0.98fr] lg:gap-16">
          {/* Narrative */}
          <div className="lg:pt-4">
            <span className="lar-eyebrow flex items-center gap-2">
              <span className="h-px w-8 bg-primary/30" />
              People Operations · Leave Routing
            </span>
            <h1 className="mt-5 font-heading text-[2.15rem] font-extrabold leading-[1.06] text-primary sm:text-[3.1rem]">
              Leave routing that
              <br className="hidden sm:block" /> never skips a Unit Manager.
            </h1>
            <p className="mt-5 max-w-md text-[14.5px] leading-relaxed text-muted-foreground">
              LAR-Sys locks every leave filing into a sequential three-role chain — Account Officer, Unit Manager
              recommendation, Area Manager approval — so field center coverage is verified before any absence is
              cleared.
            </p>

            <ol className="mt-9 space-y-0">
              {WORKFLOW_STEPS.map((step, index) => (
                <li key={step.title} className="relative flex gap-4 pb-7 last:pb-0">
                  {index < WORKFLOW_STEPS.length - 1 && (
                    <span className="absolute left-[15px] top-9 h-[calc(100%-1.75rem)] w-px bg-gradient-to-b from-primary/25 to-primary/5" />
                  )}
                  <span className="relative z-10 grid h-8 w-8 shrink-0 place-items-center rounded-full border border-primary/15 bg-card text-[12px] font-bold text-primary shadow-sm">
                    {index + 1}
                  </span>
                  <div className="pt-0.5">
                    <p className="text-[13.5px] font-bold text-foreground">{step.title}</p>
                    <p className="mt-1 max-w-sm text-[12.5px] leading-relaxed text-muted-foreground">{step.body}</p>
                  </div>
                </li>
              ))}
            </ol>

            <div className="mt-8 flex items-start gap-3 rounded-2xl border border-primary/10 bg-card/70 p-4 backdrop-blur">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              <p className="text-[12px] leading-relaxed text-muted-foreground">
                <span className="font-semibold text-foreground">Sequential by design.</span> An Area Manager can only
                act on requests already endorsed by the Unit Manager — recommendations can no longer bypass the
                immediate supervisor.
              </p>
            </div>
          </div>

          {/* Portal picker */}
          <div className="lar-panel p-5 sm:p-7">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 className="font-heading text-lg font-bold text-foreground">Select your portal</h2>
                <p className="mt-1 text-[12.5px] text-muted-foreground">
                  One-click demo access to each role in the chain.
                </p>
              </div>
              <span className="inline-flex items-center gap-1 rounded-full bg-secondary px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-primary">
                <Sparkles className="h-3 w-3" /> Demo
              </span>
            </div>

            <div className="mt-5 space-y-2.5">
              {(loading || primaryAccounts.length === 0) &&
                [0, 1, 2].map((key) => <div key={key} className="h-[78px] animate-pulse rounded-xl border border-border bg-secondary/50" />)}
              {primaryAccounts.map((employee) => {
                const meta = roleMeta(employee.role);
                const isSelected = employee.employee_id === selectedId;
                return (
                  <button
                    key={employee.employee_id}
                    type="button"
                    onClick={() => setSelectedId(employee.employee_id)}
                    className={cn(
                      "flex w-full items-center gap-3.5 rounded-xl border p-3.5 text-left transition-all duration-200",
                      isSelected
                        ? "border-primary/40 bg-accent/60 shadow-[0_10px_26px_-22px_hsl(var(--brand-navy))]"
                        : "border-border bg-card hover:border-primary/25 hover:bg-secondary/50",
                    )}
                  >
                    <span
                      className={cn(
                        "grid h-11 w-11 shrink-0 place-items-center rounded-xl font-heading text-[13px] font-extrabold transition",
                        isSelected ? "bg-primary text-white" : "bg-secondary text-primary",
                      )}
                    >
                      {initials(employee.full_name)}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex flex-wrap items-center gap-2">
                        <span className="truncate text-[14px] font-bold text-foreground">{employee.full_name}</span>
                        <RoleBadge role={employee.role} showLabel={false} size="sm" />
                      </span>
                      <span className="mt-1 block truncate font-mono text-[11px] text-muted-foreground">
                        {employee.email} · Password123
                      </span>
                      <span className="mt-1 block truncate text-[11.5px] text-muted-foreground">{meta.tagline}</span>
                    </span>
                    <span
                      className={cn(
                        "grid h-5 w-5 shrink-0 place-items-center rounded-full border transition",
                        isSelected ? "border-primary bg-primary text-primary-foreground" : "border-input text-transparent",
                      )}
                    >
                      <Check className="h-3 w-3" strokeWidth={3} />
                    </span>
                  </button>
                );
              })}
            </div>

            <button
              type="button"
              onClick={enterPortal}
              disabled={!selected || loading}
              className="mt-6 inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary text-[14px] font-semibold text-white shadow-[0_16px_30px_-18px_hsl(var(--brand-navy))] transition hover:bg-primary/92 active:scale-[0.995] disabled:pointer-events-none disabled:opacity-50"
            >
              {loading ? "Loading accounts…" : selected ? `Enter ${roleMeta(selected.role).portal}` : "Select a portal"}
              <ArrowRight className="h-4 w-4" />
            </button>

            <p className="mt-3 text-center text-[11px] leading-relaxed text-muted-foreground">
              Switch between the three accounts anytime from the profile menu to test the full lifecycle.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}