import { useCallback, useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";

export function useLeaveData() {
  const [leaves, setLeaves] = useState([]);
  const [workflows, setWorkflows] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const [leaveRes, workflowRes, employeeRes] = await Promise.all([
      base44.entities.LeaveApplication.list({ sort: "-filed_at", limit: 200 }),
      base44.entities.ApprovalWorkflow.list({ sort: "-updated_at", limit: 200 }),
      base44.entities.Employee.list({ sort: "employee_id", limit: 200 }),
    ]);
    setLeaves(leaveRes?.items ?? []);
    setWorkflows(workflowRes?.items ?? []);
    setEmployees(employeeRes?.items ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
    const unsubscribeLeaves = base44.entities.LeaveApplication.subscribe(() => load());
    const unsubscribeWorkflows = base44.entities.ApprovalWorkflow.subscribe(() => load());
    return () => {
      unsubscribeLeaves?.();
      unsubscribeWorkflows?.();
    };
  }, [load]);

  return { leaves, workflows, employees, loading, reload: load };
}

export function workflowFor(workflows, leaveId) {
  return workflows.find((item) => item.leave_id === leaveId) ?? null;
}